use mysqljdbc;
create TABLE `CustomerRegister` (
	`UserId` VARCHAR(50) NOT NULL ,
	`Password` VARCHAR(50) NOT NULL,
	`ConfirmPassword` VARCHAR(50) NOT NULL,
	`FirstName` VARCHAR(20) NOT NULL,
	`LastName` VARCHAR(20) NOT NULL,
	`Gender` VARCHAR(50) NOT NULL,
	`Age` VARCHAR(50) NOT NULL,
	`TelephoneNo` VARCHAR(20) NOT NULL,
	`MobileNo` VARCHAR(20) NOT NULL,
	`Email` VARCHAR(50) NOT NULL,
	`Address` VARCHAR(20) NOT NULL,
	`Pincode` VARCHAR(20) NOT NULL,
	`AnnualIncome` VARCHAR(50) NOT NULL
	);
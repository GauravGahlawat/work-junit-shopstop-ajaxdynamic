package com.niit.demo;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyConcatenatorTest {

	@Test
	public void testConcatenate() {
			String concatenated = MyConcatenator.concatenate("Java","Junit","Mockito","JMeter");
			assertEquals("Java,Junit,Mockito,JMeter", concatenated);
				
	}

}

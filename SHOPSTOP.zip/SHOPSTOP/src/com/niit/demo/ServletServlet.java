package com.niit.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletServlet
 */
@WebServlet("/ServletServlet")
public class ServletServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("<html>");
		out.print("<head>");
		out.print("<title>Servlet Hello World</title>");
		out.print("</head>");
		out.print("<body bgcolor=\"#ffffff\">");
		out.print("<h1>Request methods</h1>");
		out.print("<h1>Servlet Servlet at :" +request.getContextPath()+ "</h1>");
		out.print("<h1>Servlet ServletServlet Requested URI :" +request.getRequestURI()+ "</h1>");
		out.print("<h1>Servlet Servlet protocol :" +request.getProtocol()+ "</h1>");
		out.print("<b>Server Name: </b>" +request.getServerName()+"<br/>");
		out.print("<b>Server Port Number: </b>" +request.getServerPort()+"<br/>");
		out.print("<h3>Random Value for each request :" +Math.random()+ "</h3>");
		out.print("</body>");
		out.print("</html>");
		out.close();
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

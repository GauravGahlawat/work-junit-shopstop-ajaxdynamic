package test;

public class DiscountBeans {
	
	
	private double totalamt=0;

	public DiscountBeans() {
		super();
	}

	public double getTotalamt() {
		return (totalamt*0.02);
	}

	public void setTotalamt(double totalamt) {
		this.totalamt = totalamt;
	}
	

}

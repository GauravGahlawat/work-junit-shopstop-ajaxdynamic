package com.niit.mockito;

import static org.junit.Assert.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.junit.Test;

public class MockitoHelloWorld {

	@Test
	public void demoGreets() {
		Demo d= mock(Demo.class);   //create mock object
		when(d.greet()).thenReturn("HELLO_WORLD");  //training the mockito
		System.out.println("Demo Greets :" +d.greet());
		assertEquals(d.greet() , "HELLO_WORLD");
	}

	
}

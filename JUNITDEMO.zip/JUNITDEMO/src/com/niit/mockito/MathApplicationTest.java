package com.niit.mockito;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.class)
public class MathApplicationTest {
	
	// this snnotation is used to create and inject mock object
	@InjectMocks
	MathApplication mathApplication = new MathApplication();
	
	@Mock
	CalculatorService calcService;

	@Test
	public void testAdd() {
		// add behaviour of calc service to add two numbers
		when(calcService.add(10.0, 20.0)).thenReturn(30.00);
		 
		// test the add functionality
		Assert.assertEquals(mathApplication.add(10.0, 20.0), 30.0,0);
		
		verify(calcService).add(10.0,20.0); // verify is used to chech you passing same argument
		System.out.println(verify(calcService).add(10.0,20.0));
	}

}

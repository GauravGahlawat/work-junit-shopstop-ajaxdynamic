package com.niit.junit;

import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.Assert;

public class SuiteTest2 {

	@Test
	public void createAndSetName() {
		String actual = "Y";
		String expected = "Y";
		
		Assert.assertEquals(expected, actual);
		System.out.println("Suite test 2 is successfull" + actual);
	}

}
